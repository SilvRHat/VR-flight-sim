using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;


[RequireComponent(typeof(AudioSource))]
public class P3D_Audio : MonoBehaviour
{
    public string path = "";        // Path to file that checks for audio input
    public float framerate = 6;    // Times to update per second

    private int lines=0;



    private IEnumerator PlayAudioWithYield(string audioFile, float delay) {
        yield return new WaitForSeconds(delay);
        AudioClip clip = UnityEditor.AssetDatabase.LoadAssetAtPath(String.Format("Assets/Audio/{0}", audioFile), 
            typeof(AudioClip)) as AudioClip;
        AudioSource.PlayClipAtPoint(clip, new Vector3(0,0,0));
    }

    void OnUpdate() {
        using (StreamReader file = new StreamReader(path)) {
            string newline;
            // Read Previous Lines
            for (int i = 0; i < lines; i++) 
            {
                newline = file.ReadLine();
            }
            // Read New Lines
            while (true) 
            { 
                newline = file.ReadLine();
                if (newline==null)
                    break;
                lines+=1;

                // Parse line and run audio function
                string func, audiofile; float delay;
                string[] parsed = newline.Split(' ');

                func = parsed[0]; audiofile = parsed[1];
                float.TryParse(parsed[2], out delay);

                if (func=="PlayAudio")
                    StartCoroutine(PlayAudioWithYield(audiofile, delay));
            }
            file.Close();
        }
    }


    private IEnumerator _MyUpdateLoop() 
    {
        yield return new WaitForSeconds(1/framerate);
        OnUpdate();
        StartCoroutine(_MyUpdateLoop());
    }

    void Start()
    {
        using (StreamReader file = new StreamReader(path)) 
        {
            while (file.ReadLine()!=null)
                lines+=1;
            file.Close();
        }
        StartCoroutine(_MyUpdateLoop());
    }
}
